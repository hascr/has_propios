# import models #Odoo 8 hacia atras
from . import models
