.. image:: https://img.shields.io/badge/licence-LGPL--3-brightgreen
    :target: https://www.gnu.org/licenses/lgpl-3.0.html
    :alt: LGPL-3

=====================================================================
Consultar Información de Clientes en Hacienda Costa Rica
=====================================================================

.. image:: static/description/icon.png
    :width: 10%
    :alt: Module Icon
    :align: right

Actualización automática de nombre de clientes a partir del API de Hacienda

Autores:
~~~~~~~~~~~~~~~~~~~~~~~~~~
* Odoo CR
* Factura Sempai
* FSS Solutions